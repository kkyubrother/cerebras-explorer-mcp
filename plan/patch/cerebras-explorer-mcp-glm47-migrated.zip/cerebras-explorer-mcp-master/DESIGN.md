# cerebras-explorer-mcp 기획서

## 1. 배경

요구사항은 단순한 “Cerebras 연동”이 아니라 다음과 같습니다.

- 메인 모델은 Claude Code 또는 Codex 그대로 유지한다.
- Cerebras는 **서브 개념**이어야 한다.
- 사용할 모델은 기본값 `zai-glm-4.7`이지만, 필요하면 환경 변수로 바꿀 수 있다.
- 목적은 코드 생성 보조가 아니라 **탐색(explorer)** 이다.
- 상위 모델이 여러 번 `Read/Grep/Glob`를 쓰지 않고, **한 번 위임**하면 explorer가 자율적으로 파일을 찾고 읽고 결론을 내야 한다.
- 그 결과로 Claude Code / Codex 사용량을 절감해야 한다.

이 기획서는 위 요구를 만족하는 MCP 기반 external explorer를 정의한다.

---

## 2. 입력 근거

### 2.1 Claude Code 소스에서 가져온 방향

업로드된 Claude Code 소스 기준으로 다음 특징이 보인다.

1. built-in `Explore` agent는 **빠른 read-only 탐색기** 역할이다.
   - 파일 수정이 금지된다.
   - glob / grep / read 중심으로 탐색한다.
   - 최종 보고를 직접 메시지로 돌려준다.
   - 빠른 탐색을 위해 `CLAUDE.md`를 생략한다.

2. custom agent는 frontmatter로 제어할 수 있다.
   - `mcpServers`
   - `disallowedTools`
   - `model`
   - 기타 prompt / 도구 범위

3. skill은 `context: fork` + `agent:` 구조를 통해 분리된 하위 컨텍스트를 사용할 수 있다.

이것은 “탐색 전용 sub-agent”라는 개념이 Claude Code의 철학과 잘 맞는다는 뜻이다.

### 2.2 기존 `cerebras-code-mcp` 저장소에서 가져온 방향

업로드된 `cerebras-code-mcp`는 다음 형태다.

- MCP 서버 하나
- 고수준 도구 하나(`write`)
- 내부적으로 Cerebras chat completion 호출

가져올 점:

- **MCP tool 하나로 상위 모델의 복잡한 워크플로를 감춘다**는 점
- Cerebras 호출을 서버 내부 구현으로 숨긴다는 점

버릴 점:

- 쓰기 중심 설계
- `zai-glm-4.7` 기본값
- 코드 생성/수정 도구 중심 UX

결론적으로 이번 설계는 기존 `write` MCP를 `explore_repo`로 치환한 읽기 전용 구조다.

---

## 3. 핵심 목표

### 목표

- 상위 모델은 **한 번만 위임**한다.
- 자율 탐색 루프는 **MCP 서버 내부에서** 끝난다.
- 상위 모델 토큰을 아끼기 위해, low-level 파일 검색 도구는 부모에게 넘기지 않는다.
- 반환은 항상 구조화된 JSON이다.

### 비목표

- 코드 수정
- 테스트 실행
- 셸 명령 자동 실행

> **참고:** 런타임 모델 자동 라우팅(`CEREBRAS_EXPLORER_AUTO_ROUTE`)과 failover provider(`EXPLORER_FAILOVER`) 기능이 내부 구현으로 존재하지만, 공개 계약(제품 목표)은 **Cerebras 기반 explorer**에 한정한다. 해당 기능은 내부 구현 메모 수준이며, 지원을 약속하는 공개 기능이 아니다.

---

## 4. 왜 low-level MCP 도구를 직접 노출하지 않는가

잘못된 설계는 이런 형태다.

```text
Parent model
  -> repo_list_dir
  -> repo_grep
  -> repo_read_file
  -> repo_read_file
  -> repo_grep
  -> ...
```

이 구조에서는 탐색 orchestration을 부모 모델이 맡게 된다. 그러면 결국 Claude/Codex가 계속 탐색 토큰을 소비하게 되고, “Cerebras를 explorer로 써서 메인 사용량을 줄인다”는 목표가 약해진다.

따라서 바른 설계는 이 형태다.

```text
Parent model
  -> explore_repo(...)
    -> explorer runtime
      -> model-driven tool loop
      -> structured result
```

즉, `explore_repo`는 단순한 편의 함수가 아니라 **독립 실행형 explorer 서브시스템의 단일 진입점**이다.

---

## 5. 아키텍처

```text
Claude Code / Codex
  -> MCP: explore_repo
    -> ExplorerRuntime
      -> RepoToolkit
         - repo_list_dir
         - repo_find_files
         - repo_grep
         - repo_symbols
         - repo_references
         - repo_symbol_context
         - repo_read_file
         - repo_git_log
         - repo_git_blame
         - repo_git_diff
         - repo_git_show
      -> CerebrasChatClient
         - model: configurable via env (default zai-glm-4.7)
      -> final grounded JSON
```

### 5.1 컴포넌트 역할

#### `RepoToolkit`

저장소를 읽기 전용으로 탐색한다.

- 디렉터리 목록
- 파일 glob 검색
- 정규식 grep
- 심볼 정의 추출
- 심볼 사용처 추적
- 심볼 컨텍스트 매크로 호출
- 특정 파일 라인 범위 읽기
- git 이력 조회, blame, diff, show

#### `CerebrasChatClient`

Cerebras chat completion API에 직접 연결한다.

- 모델 기본값: `zai-glm-4.7`
- override: `CEREBRAS_EXPLORER_MODEL` 또는 `CEREBRAS_MODEL`
- tool calling 지원
- structured final JSON 유도

**Cerebras API 호환성 주의사항**

Cerebras는 OpenAI 호환 API를 제공하지만, 일부 OpenAI 전용 파라미터는 지원하지 않는다. 지원하지 않는 파라미터를 포함하면 `422 Unprocessable Entity` 에러가 발생한다.

| 파라미터 | OpenAI | Cerebras | 비고 |
|---------|--------|----------|------|
| `tools[].function.strict` | ✅ | ❌ | tool argument 스키마 강제 검증 (OpenAI 전용) |
| `clear_thinking` | ❌ | ✅ (GLM 4.7 전용) | multi-turn agent loop에서 이전 reasoning 보존 |
| `response_format.json_schema.strict` | ✅ | ✅ | structured output 스키마 강제 (지원됨) |
| `reasoning_effort` | ✅ | ✅ | GLM 4.7에서는 `"none"`만 사용해 reasoning을 끄고, 기본 reasoning은 파라미터를 생략해 유지 |
| assistant `reasoning` field | ❌ | ✅ | reasoning이 있는 assistant 메시지를 다음 turn에 다시 넘겨 preserved thinking을 유지 |

`tools[].function.strict`와 `response_format.json_schema.strict`는 이름이 같지만 위치와 역할이 다르다. 전자는 tool 인자 검증(OpenAI 전용), 후자는 응답 JSON 스키마 강제(Cerebras 지원)이다.

GLM 4.7 마이그레이션 기준으로 explorer runtime은 다음 원칙을 따른다.

- quick budget: `reasoning_effort="none"`
- normal/deep budget: reasoning 파라미터를 생략해 기본 reasoning 유지
- multi-turn tool loop: `clear_thinking=false` + assistant `reasoning` 재주입으로 preserved thinking 유지
- 샘플링 기본값: `temperature=1`, `top_p=0.95`

#### `ExplorerRuntime`

실제 autonomous loop를 담당한다.

- system/user prompt 구성
- budget 설정
- tool loop 실행
- evidence grounding
- 최종 결과 정규화

#### `MCP Server`

기본적으로 상위 모델에게 5개의 도구를 노출한다: `explore_repo`, `explain_symbol`, `trace_dependency`, `summarize_changes`, `find_similar_code`. `CEREBRAS_EXPLORER_EXTRA_TOOLS=false`로 설정하면 `explore_repo` 하나만 노출된다.

---

## 6. 독립성 정의

여기서 “main과 독립적인 explorer”는 다음 의미다.

1. 부모는 내부 탐색 단계를 모르고, 안 알아도 된다.
2. explorer는 자신의 도구 루프를 스스로 결정한다.
3. 부모는 결과만 받고 필요한 경우 일부 evidence만 재검증한다.
4. explorer 컨텍스트는 부모 대화와 분리된다.

즉, 이 explorer는 Claude Code 내장 Explore와 비슷한 역할을 하지만, **외부 MCP 뒤에서 선택된 Cerebras 모델로 돌아간다**는 점이 다르다.

---

## 7. 모델 정책

- 기본 모델: `zai-glm-4.7`
- override: `CEREBRAS_EXPLORER_MODEL` 또는 `CEREBRAS_MODEL`
- budget별 모델 지정: `CEREBRAS_EXPLORER_MODEL_QUICK`, `CEREBRAS_EXPLORER_MODEL_NORMAL`, `CEREBRAS_EXPLORER_MODEL_DEEP`

이 프로젝트의 문서화된 계약은 Cerebras provider 기준이다. 모델 이름은 바꿀 수 있지만, 부모 모델이 아닌 explorer 내부 모델만 교체한다.

내부 구현에는 `EXPLORER_PROVIDER` 및 `EXPLORER_FAILOVER` 환경변수를 통한 provider 전환/failover 기능이 존재하나, 이는 공개 계약이 아닌 내부 구현이다.

---

## 8. 내부 도구 설계

### 8.1 `repo_list_dir`

저장소 구조 감잡기용.

### 8.2 `repo_find_files`

파일명/패턴 기반 후보 압축용.

### 8.3 `repo_grep`

심볼, 라우트, 설정 키, 문자열 흔적 찾기용.

- `contextLines` 옵션으로 전후 문맥을 함께 반환할 수 있다.

### 8.4 `repo_symbols`

파일 안의 함수, 클래스, 변수, 타입 정의를 추출한다.

- 현재 구현은 tree-sitter가 아니라 **regex 기반 경량 심볼 인덱서**다.
- 지원 언어별 패턴으로 `{name, kind, line, endLine, exported}`를 만든다.

### 8.5 `repo_references`

특정 심볼의 사용처를 코드베이스 전역에서 찾는다.

- 각 매치를 `import`, `definition`, `usage`로 분류한다.
- 정확한 semantic reference resolver가 아니라 grep + 분류기 기반이다.

### 8.6 `repo_symbol_context`

심볼 하나에 대해 정의 본문과 호출자 정보를 한 번에 반환하는 매크로 도구다.

- symbol-first, reference-chase 질문에서 첫 진입점으로 사용한다.
- 현재 `depth`는 인터페이스상 존재하지만 실질적으로 1단계 수준만 구현돼 있다.

### 8.7 `repo_read_file`

필요한 라인 범위만 읽기용.

### 8.8 `repo_git_log`

특정 파일/디렉터리 또는 전체 저장소의 최근 커밋 흐름을 본다.

### 8.9 `repo_git_blame`

파일의 특정 라인 범위에 대한 작성자와 커밋 정보를 본다.

### 8.10 `repo_git_diff`

두 ref 사이 변경 파일과 patch 또는 diffstat을 본다.

### 8.11 `repo_git_show`

특정 커밋의 메시지와 변경 파일을 본다.

이 도구 집합으로 구조 탐색, 심볼 추적, 코드 읽기, 변경 이력 분석까지 모두 처리한다.

---

## 9. 반환 스키마

```json
{
  "answer": "string",
  "summary": "string",
  "confidence": "low|medium|high",
  "confidenceScore": 0.0,
  "confidenceFactors": {
    "evidenceCount": 0,
    "evidenceDropped": 0,
    "crossVerified": false,
    "symbolSearchUsed": false,
    "stoppedByBudget": false,
    "adjustments": []
  },
  "evidence": [
    {
      "path": "relative/path",
      "startLine": 1,
      "endLine": 10,
      "why": "why it matters",
      "groundingStatus": "exact|partial"
    }
  ],
  "candidatePaths": ["relative/path"],
  "followups": [
    {
      "description": "optional next check",
      "priority": "recommended|optional",
      "suggestedCall": {
        "task": "string",
        "scope": ["relative/path/or/glob"],
        "budget": "quick|normal|deep",
        "hints": {
          "symbols": ["string"],
          "strategy": "symbol-first|reference-chase|git-guided|breadth-first|blame-guided|pattern-scan"
        }
      }
    }
  ],
  "codeMap": {
    "entryPoints": ["relative/path"],
    "keyModules": [
      {
        "path": "relative/path",
        "role": "string",
        "linesRead": 0
      }
    ]
  },
  "diagram": "optional mermaid flowchart",
  "recentActivity": {
    "hotFiles": ["relative/path (N commits / range)"],
    "recentAuthors": ["name"],
    "lastModified": "YYYY-MM-DD",
    "recentCommits": [
      {"hash": "abc123", "message": "string", "date": "ISO"}
    ]
  },
  "stats": {
    "model": "${CEREBRAS_EXPLORER_MODEL:-zai-glm-4.7}",
    "budget": "quick|normal|deep",
    "turns": 0,
    "toolCalls": 0,
    "sessionId": "sess_..."
  }
}
```

반환을 자연어가 아니라 JSON으로 고정한 이유:

- Claude Code / Codex가 후처리하기 쉽다.
- UI / 로그 / 캐싱이 쉬워진다.
- evidence 재검증이 쉬워진다.

---

## 10. evidence grounding 정책

탐색형 agent의 가장 큰 문제는 “읽지 않은 파일을 안 읽은 척 결론에 넣는 것”이다.

이를 줄이기 위해 구현은 다음 규칙을 갖는다.

- `repo_read_file`로 실제 읽은 line range를 기록한다.
- `repo_grep`로 실제 일치한 line을 기록한다.
- 최종 evidence는 **기록된 line range와 겹치는 항목만 유지**한다.
- 누락된 evidence가 있으면 confidence를 낮춘다.

이 정책 덕분에 “탐색은 했다고 하는데 근거가 빈약한” 출력을 줄일 수 있다.

---

## 11. 경계 강화 정책

초기 `scope`는 advisory가 아니라 **hard boundary**로 취급한다.

- `repo_find_files`와 `repo_grep`의 추가 `scope`는 초기 범위를 **더 좁히기만** 할 수 있다.
- `repo_list_dir`는 현재 scope 밖 디렉터리를 나열하지 않는다.
- 디렉터리 순회는 scope와 무관한 하위 트리를 큐에 넣지 않는다.
- symlink 항목은 순회 결과에서 숨기고, 직접 읽으려 해도 거부한다.
- 실제 경로는 `realpath`로 확인해 repo root 밖 탈출을 막는다.

즉, scope 확장과 symlink 탈출을 모두 막아서, explorer가 부모가 준 저장소 경계를 넘지 못하게 한다.

---

## 11. budget 정책

### `quick`

- 빠른 1차 탐색
- 얕은 검색
- 토큰 절감 우선

### `normal`

- 대부분의 기본 동작

### `deep`

- 더 많은 반복 탐색 허용
- 넓은 후보군 탐색 가능

이 budget은 상위 모델이 질문 중요도에 따라 조절할 수 있다.

---

## 12. Claude Code 통합 방식

Claude Code에서는 두 층으로 붙인다.

### A. MCP 서버 등록

Claude는 `explore_repo`를 하나의 외부 고수준 도구로 본다.

### B. 얇은 sub-agent / skill

- custom agent: 외부 explorer를 우선 사용하도록 지시
- skill: 탐색형 과제에서 그 agent를 부르도록 유도

핵심은 Claude의 native `Read/Grep/Glob`를 먼저 쓰지 않고, **외부 explorer를 먼저 호출**하게 만드는 것이다.

---

## 13. Codex 통합 방식

Codex도 동일하다.

- MCP 서버 등록
- read-only custom agent 정의
- skill 또는 AGENTS.md 규칙으로 explorer 우선 위임

즉, 공용 핵심은 MCP 서버이고, 각 도구별 glue는 얇다.

---

## 14. 구현 범위

### 포함

- MCP stdio 서버 (Content-Length 방식 + NDJSON 방식 자동 감지)
- `explore_repo`
- 내부 repo toolkit
- Cerebras API 클라이언트
- autonomous tool loop
- 심볼/참조 추적용 경량 regex 기반 인덱서
- git 메타데이터 기반 탐색
- 세션 기반 후속 탐색
- MCP progress notification
- 기본 테스트
- Claude/Codex integration 예시

### 제외

- 공식 MCP SDK 의존성
- tree-sitter/LSP 기반 정밀 semantic 분석
- 병렬 repo 샤딩 탐색
- write-back agent

---

## 15. 추후 확장

### Phase 2

- `trace_symbol`
- `map_impact`
- `find_entrypoints`
- nested `.gitignore` / `.ignore` 지원
- `repo_symbol_context.depth > 1` 확장
- `repo_grep.includeSymbol`

### Phase 3

- tree-sitter 기반 구조 인덱스
- import graph / call graph
- 정량화된 유사도 점수 (`find_similar_code.similarity`)
- repo fingerprint 기반 warm-start

---

## 16. 한 줄 결론

이 설계의 핵심은 다음 문장으로 요약된다.

> **Claude/Codex의 subagent 기능을 직접 메인으로 쓰는 것이 아니라, `zai-glm-4.7` 기반의 외부 autonomous explorer를 MCP 뒤에 숨기고, 메인 모델은 그 explorer에게 한 번만 위임하게 만든다.**

이것이 “main과 독립적인 explorer 기능을 갖춘 MCP sub-agent” 요구에 가장 가깝다.
