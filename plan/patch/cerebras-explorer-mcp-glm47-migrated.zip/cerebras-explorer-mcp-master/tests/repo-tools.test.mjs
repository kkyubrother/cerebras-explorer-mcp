import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

import { getBudgetConfig } from '../src/explorer/config.mjs';
import { RepoToolkit, collectCandidatePathsFromToolResult } from '../src/explorer/repo-tools.mjs';

function hasGit() {
  try { execFileSync('git', ['--version'], { stdio: 'pipe' }); return true; } catch { return false; }
}
function hasRipgrep() {
  try { execFileSync('rg', ['--version'], { stdio: 'pipe' }); return true; } catch { return false; }
}

async function makeGitRepoFixture() {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'cerebras-git-'));
  const git = (args) => execFileSync('git', args, { cwd: root, stdio: 'pipe', encoding: 'utf8' });
  git(['init', '-b', 'main']);
  git(['config', 'user.email', 'test@example.com']);
  git(['config', 'user.name', 'Test User']);
  await fs.writeFile(path.join(root, 'hello.js'), 'console.log("hello");\n');
  git(['add', '.']);
  git(['commit', '-m', 'initial commit: add hello.js']);
  await fs.writeFile(path.join(root, 'hello.js'), 'console.log("hello world");\n');
  git(['add', '.']);
  git(['commit', '-m', 'update: expand greeting']);
  return root;
}

async function makeRepoFixture() {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'cerebras-explorer-'));
  await fs.mkdir(path.join(root, 'src', 'routes'), { recursive: true });
  await fs.mkdir(path.join(root, 'docs'), { recursive: true });
  await fs.mkdir(path.join(root, 'ignored'), { recursive: true });
  await fs.writeFile(path.join(root, '.gitignore'), 'ignored/\n');
  await fs.writeFile(
    path.join(root, 'src', 'auth.js'),
    [
      'export function requireAuth(req, res, next) {',
      '  if (!req.user) throw new Error("unauthorized");',
      '  next();',
      '}',
      '',
      'export const AUTH_HEADER = "x-auth-token";',
    ].join('\n'),
  );
  await fs.writeFile(
    path.join(root, 'src', 'routes', 'user.js'),
    [
      'import { requireAuth } from "../auth.js";',
      '',
      'export function registerUserRoutes(app) {',
      '  app.get("/users/me", requireAuth, (req, res) => {',
      '    res.json({ id: req.user.id });',
      '  });',
      '}',
    ].join('\n'),
  );
  await fs.writeFile(
    path.join(root, 'docs', 'auth.md'),
    '# Auth\n\nThe user route uses requireAuth before handling /users/me.\n',
  );
  await fs.writeFile(path.join(root, 'ignored', 'secret.txt'), 'do not index');
  await fs.writeFile(path.join(root, 'logo.png'), Buffer.from([0, 1, 2, 3, 4]));
  return root;
}

test('RepoToolkit finds files, greps, reads ranges, and respects gitignore', async () => {
  const repoRoot = await makeRepoFixture();
  const toolkit = new RepoToolkit({
    repoRoot,
    budgetConfig: getBudgetConfig('normal'),
  });
  await toolkit.initialize(['src/**', 'docs/**']);

  const found = await toolkit.findFiles({ pattern: 'src/**/*.js' });
  assert.deepEqual(found.matches.sort(), ['src/auth.js', 'src/routes/user.js']);

  const grep = await toolkit.grep({ pattern: 'requireAuth' });
  assert.equal(grep.matches.length >= 2, true);
  assert.equal(grep.matches.some(match => match.path === 'src/auth.js'), true);
  assert.equal(grep.matches.some(match => match.path === 'src/routes/user.js'), true);
  assert.equal(grep.matches.some(match => match.path === 'ignored/secret.txt'), false);

  const read = await toolkit.readFile({ path: 'src/routes/user.js', startLine: 1, endLine: 4 });
  assert.equal(read.startLine, 1);
  assert.equal(read.endLine, 4);
  assert.match(read.content, /4 \|   app.get\("\/users\/me", requireAuth/);

  const listing = await toolkit.listDirectory({ dirPath: '.', depth: 2 });
  assert.equal(listing.entries.some(entry => entry.path === 'ignored/secret.txt'), false);
  assert.equal(listing.entries.some(entry => entry.path === 'src/auth.js'), true);
});

test('RepoToolkit enforces the initial scope as a hard boundary', async () => {
  const repoRoot = await makeRepoFixture();
  const toolkit = new RepoToolkit({
    repoRoot,
    budgetConfig: getBudgetConfig('normal'),
  });
  await toolkit.initialize(['src/**']);

  const listing = await toolkit.listDirectory({ dirPath: '.', depth: 2 });
  assert.equal(listing.entries.some(entry => entry.path === 'src'), true);
  assert.equal(listing.entries.some(entry => entry.path === 'docs'), false);
  assert.equal(listing.entries.some(entry => entry.path === 'docs/auth.md'), false);

  const expandedFind = await toolkit.findFiles({
    pattern: 'docs/**/*.md',
    scope: ['docs/**'],
  });
  assert.deepEqual(expandedFind.matches, []);

  const expandedGrep = await toolkit.grep({
    pattern: 'Auth',
    scope: ['docs/**'],
  });
  assert.deepEqual(expandedGrep.matches, []);

  await assert.rejects(
    toolkit.listDirectory({ dirPath: 'docs', depth: 1 }),
    /Directory is outside current scope: docs/,
  );
});

test('RepoToolkit blocks symlink reads and skips symlink entries during traversal', async () => {
  const repoRoot = await makeRepoFixture();
  const outsideDir = await fs.mkdtemp(path.join(os.tmpdir(), 'cerebras-explorer-outside-'));
  const outsideFile = path.join(outsideDir, 'outside-secret.txt');
  await fs.writeFile(outsideFile, 'outside secret');

  const fileLinkPath = path.join(repoRoot, 'src', 'linked-secret.txt');
  const dirLinkPath = path.join(repoRoot, 'src', 'linked-dir');
  await fs.symlink(outsideFile, fileLinkPath);
  await fs.symlink(outsideDir, dirLinkPath, 'dir');

  const toolkit = new RepoToolkit({
    repoRoot,
    budgetConfig: getBudgetConfig('normal'),
  });
  await toolkit.initialize(['src/**']);

  const listing = await toolkit.listDirectory({ dirPath: 'src', depth: 2 });
  assert.equal(listing.entries.some(entry => entry.path === 'src/linked-secret.txt'), false);
  assert.equal(listing.entries.some(entry => entry.path === 'src/linked-dir'), false);

  const found = await toolkit.findFiles({ pattern: 'src/**/*.txt' });
  assert.deepEqual(found.matches, []);

  await assert.rejects(
    toolkit.readFile({ path: 'src/linked-secret.txt', startLine: 1, endLine: 1 }),
    /Symlinks are not supported|Path resolves outside repo root/,
  );
});

test('collectCandidatePathsFromToolResult handles git diff and show results', () => {
  const diffResult = { from: 'HEAD~1', to: 'HEAD', files: [{ path: 'src/foo.js', additions: 2, deletions: 1, patch: '' }] };
  assert.deepEqual(collectCandidatePathsFromToolResult('repo_git_diff', diffResult), ['src/foo.js']);

  const showResult = { hash: 'abc', author: 'a', date: 'd', message: 'm', files: [{ path: 'src/bar.js', additions: 1, deletions: 0, patch: '' }] };
  assert.deepEqual(collectCandidatePathsFromToolResult('repo_git_show', showResult), ['src/bar.js']);

  assert.deepEqual(collectCandidatePathsFromToolResult('repo_git_log', { commits: [] }), []);
  assert.deepEqual(collectCandidatePathsFromToolResult('repo_git_blame', { lines: [] }), []);
});

test('RepoToolkit git tools: gitLog returns commits', { skip: !hasGit() }, async () => {
  const root = await makeGitRepoFixture();
  const toolkit = new RepoToolkit({ repoRoot: root, budgetConfig: getBudgetConfig('normal') });
  await toolkit.initialize();

  const log = await toolkit.gitLog({ maxCount: 10 });
  assert.ok(Array.isArray(log.commits), 'commits is an array');
  assert.ok(log.commits.length >= 2, 'at least 2 commits');
  assert.ok(log.commits[0].hash, 'commit has hash');
  assert.ok(log.commits[0].author, 'commit has author');
  assert.ok(log.commits[0].message, 'commit has message');
});

test('RepoToolkit git tools: gitLog filters by file path', { skip: !hasGit() }, async () => {
  const root = await makeGitRepoFixture();
  const toolkit = new RepoToolkit({ repoRoot: root, budgetConfig: getBudgetConfig('normal') });
  await toolkit.initialize();

  const log = await toolkit.gitLog({ path: 'hello.js', maxCount: 5 });
  assert.ok(log.commits.length >= 1, 'has commits for hello.js');
  assert.ok(log.commits.some(c => c.message.includes('greeting')), 'second commit found');
});

test('RepoToolkit git tools: gitBlame returns line authorship', { skip: !hasGit() }, async () => {
  const root = await makeGitRepoFixture();
  const toolkit = new RepoToolkit({ repoRoot: root, budgetConfig: getBudgetConfig('normal') });
  await toolkit.initialize();

  const blame = await toolkit.gitBlame({ path: 'hello.js', startLine: 1, endLine: 1 });
  assert.ok(Array.isArray(blame.lines), 'lines is an array');
  assert.ok(blame.lines.length >= 1, 'at least one blamed line');
  assert.ok(blame.lines[0].hash, 'line has commit hash');
  assert.ok(blame.lines[0].author, 'line has author');
  assert.equal(blame.lines[0].line, 1, 'line number is 1');
});

test('RepoToolkit git tools: gitDiff returns file changes', { skip: !hasGit() }, async () => {
  const root = await makeGitRepoFixture();
  const toolkit = new RepoToolkit({ repoRoot: root, budgetConfig: getBudgetConfig('normal') });
  await toolkit.initialize();

  const diff = await toolkit.gitDiff({ from: 'HEAD~1', to: 'HEAD' });
  assert.ok(Array.isArray(diff.files), 'files is an array');
  assert.ok(diff.files.length >= 1, 'at least one changed file');
  assert.equal(diff.files[0].path, 'hello.js');

  const stat = await toolkit.gitDiff({ from: 'HEAD~1', to: 'HEAD', stat: true });
  assert.ok(typeof stat.stat === 'string', 'stat returns string summary');
  assert.match(stat.stat, /hello\.js/);
});

test('RepoToolkit git tools: gitShow returns commit details', { skip: !hasGit() }, async () => {
  const root = await makeGitRepoFixture();
  const toolkit = new RepoToolkit({ repoRoot: root, budgetConfig: getBudgetConfig('normal') });
  await toolkit.initialize();

  const show = await toolkit.gitShow({ ref: 'HEAD' });
  assert.ok(show.hash, 'has hash');
  assert.ok(show.author, 'has author');
  assert.ok(show.message, 'has message');
  assert.ok(Array.isArray(show.files), 'has files array');
  assert.ok(show.files.some(f => f.path === 'hello.js'), 'hello.js is in changed files');
});

test('RepoToolkit git tools: gitShow rejects invalid ref', { skip: !hasGit() }, async () => {
  const root = await makeGitRepoFixture();
  const toolkit = new RepoToolkit({ repoRoot: root, budgetConfig: getBudgetConfig('normal') });
  await toolkit.initialize();

  await assert.rejects(
    toolkit.gitShow({ ref: 'HEAD; rm -rf /' }),
    /Invalid ref/,
  );
});

test('RepoToolkit grep uses ripgrep when available', { skip: !hasRipgrep() }, async () => {
  const repoRoot = await makeRepoFixture();
  const toolkit = new RepoToolkit({ repoRoot, budgetConfig: getBudgetConfig('normal') });
  await toolkit.initialize(['src/**', 'docs/**']);

  assert.equal(toolkit._hasRipgrep, true, 'ripgrep detected');
  const result = await toolkit.grep({ pattern: 'requireAuth' });
  assert.ok(result.matches.length >= 2, 'ripgrep finds matches');
  assert.ok(result.matches.some(m => m.path === 'src/auth.js'), 'finds in auth.js');
  assert.ok(result.matches.some(m => m.path === 'src/routes/user.js'), 'finds in user.js');
});
