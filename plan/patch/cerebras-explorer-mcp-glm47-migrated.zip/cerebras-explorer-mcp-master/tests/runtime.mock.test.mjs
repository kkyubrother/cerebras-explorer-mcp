import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';

import { ExplorerRuntime } from '../src/explorer/runtime.mjs';

async function makeRepoFixture() {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'cerebras-explorer-runtime-'));
  await fs.mkdir(path.join(root, 'src', 'routes'), { recursive: true });
  await fs.writeFile(
    path.join(root, 'src', 'auth.js'),
    [
      'export function requireAuth(req, res, next) {',
      '  if (!req.user) throw new Error("unauthorized");',
      '  next();',
      '}',
    ].join('\n'),
  );
  await fs.writeFile(
    path.join(root, 'src', 'routes', 'user.js'),
    [
      'import { requireAuth } from "../auth.js";',
      '',
      'export function registerUserRoutes(app) {',
      '  app.get("/users/me", requireAuth, (req, res) => {',
      '    res.json({ id: req.user.id });',
      '  });',
      '}',
    ].join('\n'),
  );
  return root;
}

class MockChatClient {
  constructor() {
    this.model = 'zai-glm-4.7';
    this.calls = 0;
  }

  async createChatCompletion({ messages }) {
    this.calls += 1;

    if (this.calls === 1) {
      return {
        usage: { prompt_tokens: 100, completion_tokens: 20, total_tokens: 120 },
        message: {
          content: '',
          toolCalls: [
            {
              id: 'call-1',
              function: {
                name: 'repo_grep',
                arguments: JSON.stringify({ pattern: 'requireAuth', scope: ['src/**'] }),
              },
            },
          ],
        },
      };
    }

    if (this.calls === 2) {
      const lastToolMessage = messages[messages.length - 1];
      assert.equal(lastToolMessage.role, 'tool');
      assert.match(lastToolMessage.content, /requireAuth/);
      return {
        usage: { prompt_tokens: 110, completion_tokens: 20, total_tokens: 130 },
        message: {
          content: '',
          toolCalls: [
            {
              id: 'call-2',
              function: {
                name: 'repo_read_file',
                arguments: JSON.stringify({ path: 'src/routes/user.js', startLine: 1, endLine: 6 }),
              },
            },
          ],
        },
      };
    }

    if (this.calls === 3) {
      const lastToolMessage = messages[messages.length - 1];
      assert.equal(lastToolMessage.role, 'tool');
      assert.match(lastToolMessage.content, /\/users\/me/);
      return {
        usage: { prompt_tokens: 120, completion_tokens: 20, total_tokens: 140 },
        message: {
          content: '',
          toolCalls: [
            {
              id: 'call-3',
              function: {
                name: 'repo_read_file',
                arguments: JSON.stringify({ path: 'src/auth.js', startLine: 1, endLine: 4 }),
              },
            },
          ],
        },
      };
    }

    return {
      usage: { prompt_tokens: 130, completion_tokens: 40, total_tokens: 170 },
      message: {
        content: JSON.stringify({
          answer:
            'registerUserRoutes는 /users/me 라우트에 requireAuth 미들웨어를 직접 연결한다.',
          summary:
            'auth.js에서 requireAuth를 정의하고, user.js에서 이를 import해 /users/me에 적용한다.',
          confidence: 'high',
          evidence: [
            {
              path: 'src/routes/user.js',
              startLine: 1,
              endLine: 4,
              why: '라우트가 requireAuth를 import하고 /users/me에 연결한다.',
            },
            {
              path: 'src/auth.js',
              startLine: 1,
              endLine: 4,
              why: 'requireAuth의 실제 동작이 여기 정의되어 있다.',
            },
          ],
          candidatePaths: ['src/routes/user.js', 'src/auth.js'],
          followups: [
            {
              description: '미들웨어 에러 핸들링 패턴 추가 분석',
              priority: 'optional',
              suggestedCall: {
                task: 'Analyze error handling in auth middleware',
                scope: ['src/**'],
                budget: 'quick',
                hints: { symbols: ['handleAuthError'], strategy: 'symbol-first' },
              },
            },
          ],
        }),
        toolCalls: [],
      },
    };
  }
}

test('ExplorerRuntime performs an autonomous tool loop and returns structured findings', async () => {
  const repoRoot = await makeRepoFixture();
  const runtime = new ExplorerRuntime({ chatClient: new MockChatClient() });

  const result = await runtime.explore({
    task: 'users/me 라우트에 인증 미들웨어가 어떻게 붙는지 추적해라.',
    repo_root: repoRoot,
    scope: ['src/**'],
    budget: 'quick',
  });

  // Core fields
  assert.equal(result.confidence, 'high');
  assert.match(result.answer, /requireAuth/);
  assert.equal(result.evidence.length, 2);
  assert.equal(result.stats.toolCalls, 3);
  assert.equal(result.stats.grepCalls, 1);
  assert.equal(result.stats.filesRead, 2);
  assert.equal(result.candidatePaths.includes('src/routes/user.js'), true);

  // Phase 3: continuous confidence score
  assert.ok(typeof result.confidenceScore === 'number', 'confidenceScore must be a number');
  assert.ok(result.confidenceScore >= 0 && result.confidenceScore <= 1, 'confidenceScore must be in [0, 1]');
  assert.ok(['low', 'medium', 'high'].includes(result.confidenceLevel), 'confidenceLevel must be low|medium|high');
  assert.ok(result.confidenceFactors && typeof result.confidenceFactors === 'object', 'confidenceFactors must be an object');
  assert.ok(typeof result.confidenceFactors.evidenceCount === 'number', 'confidenceFactors.evidenceCount must be a number');
  assert.ok(typeof result.confidenceFactors.crossVerified === 'boolean', 'confidenceFactors.crossVerified must be a boolean');

  // Phase 3: evidence grounding status
  for (const ev of result.evidence) {
    assert.ok(ev.groundingStatus === 'exact' || ev.groundingStatus === 'partial', 'each evidence item must have groundingStatus');
  }

  // Phase 3: structured followups
  assert.ok(Array.isArray(result.followups), 'followups must be an array');
  if (result.followups.length > 0) {
    const followup = result.followups[0];
    assert.ok(typeof followup.description === 'string', 'followup.description must be a string');
    assert.ok(followup.priority === 'recommended' || followup.priority === 'optional', 'followup.priority must be recommended|optional');
  }

  // Phase 3: codeMap
  assert.ok(result.codeMap && typeof result.codeMap === 'object', 'codeMap must be present');
  assert.ok(Array.isArray(result.codeMap.entryPoints), 'codeMap.entryPoints must be an array');
  assert.ok(Array.isArray(result.codeMap.keyModules), 'codeMap.keyModules must be an array');
  assert.ok(result.codeMap.keyModules.length >= 2, 'codeMap must include at least the two read files');
});

test('ExplorerRuntime accepts legacy string followups and normalizes them', async () => {
  class LegacyFollowupClient {
    constructor() {
      this.model = 'zai-glm-4.7';
    }
    async createChatCompletion() {
      return {
        usage: { prompt_tokens: 50, completion_tokens: 20, total_tokens: 70 },
        message: {
          content: JSON.stringify({
            answer: '테스트 답변',
            summary: '테스트 요약',
            confidence: 'medium',
            evidence: [],
            candidatePaths: [],
            followups: ['추가 조사가 필요합니다'],
          }),
          toolCalls: [],
        },
      };
    }
  }

  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'cerebras-explorer-legacy-'));
  await fs.writeFile(path.join(root, 'index.js'), 'console.log("hello");');

  const runtime = new ExplorerRuntime({ chatClient: new LegacyFollowupClient() });
  const result = await runtime.explore({ task: '테스트', repo_root: root });

  assert.ok(Array.isArray(result.followups));
  if (result.followups.length > 0) {
    assert.ok(typeof result.followups[0].description === 'string', 'legacy string followup must be normalized to object');
    assert.ok(result.followups[0].priority === 'optional');
  }
});

test('ExplorerRuntime builds recentActivity when git_log tool is called', async () => {
  class GitLogClient {
    constructor() {
      this.model = 'zai-glm-4.7';
      this.calls = 0;
    }
    async createChatCompletion() {
      this.calls += 1;
      if (this.calls === 1) {
        return {
          usage: { prompt_tokens: 50, completion_tokens: 20, total_tokens: 70 },
          message: {
            content: '',
            toolCalls: [
              {
                id: 'call-git-1',
                function: {
                  name: 'repo_git_log',
                  arguments: JSON.stringify({ maxCount: 5 }),
                },
              },
            ],
          },
        };
      }
      return {
        usage: { prompt_tokens: 80, completion_tokens: 30, total_tokens: 110 },
        message: {
          content: JSON.stringify({
            answer: '최근 커밋 이력을 확인했습니다.',
            summary: '최근 변경 사항 요약',
            confidence: 'medium',
            evidence: [],
            candidatePaths: [],
            followups: [],
          }),
          toolCalls: [],
        },
      };
    }
  }

  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'cerebras-explorer-git-'));
  await fs.writeFile(path.join(root, 'index.js'), 'console.log("hello");');

  const runtime = new ExplorerRuntime({ chatClient: new GitLogClient() });
  const result = await runtime.explore({
    task: '최근에 어떤 파일이 변경되었나요?',
    repo_root: root,
    hints: { strategy: 'git-guided' },
  });

  // recentActivity may be null if git_log returned no commits (non-git dir)
  // The important thing is the field is present or absent — no crash
  assert.ok('recentActivity' in result || result.recentActivity === undefined);
  assert.equal(result.stats.gitLogCalls, 1);
});

test('ExplorerRuntime partial match evidence: evidence within tolerance lines is kept', async () => {
  class PartialMatchClient {
    constructor() {
      this.model = 'zai-glm-4.7';
      this.calls = 0;
    }
    async createChatCompletion() {
      this.calls += 1;
      if (this.calls === 1) {
        return {
          usage: { prompt_tokens: 50, completion_tokens: 10, total_tokens: 60 },
          message: {
            content: '',
            toolCalls: [
              {
                id: 'call-read-1',
                function: {
                  name: 'repo_read_file',
                  arguments: JSON.stringify({ path: 'src/auth.js', startLine: 1, endLine: 4 }),
                },
              },
            ],
          },
        };
      }
      // Evidence references lines 5-6 but we only read 1-4.
      // With EVIDENCE_LINE_TOLERANCE=2, line 5 is within tolerance → kept as partial.
      return {
        usage: { prompt_tokens: 80, completion_tokens: 20, total_tokens: 100 },
        message: {
          content: JSON.stringify({
            answer: '인증 함수가 확인됩니다.',
            summary: '요약',
            confidence: 'medium',
            evidence: [
              { path: 'src/auth.js', startLine: 5, endLine: 6, why: '함수 본문' },
            ],
            candidatePaths: ['src/auth.js'],
            followups: [],
          }),
          toolCalls: [],
        },
      };
    }
  }

  const root = await makeRepoFixture();
  const runtime = new ExplorerRuntime({ chatClient: new PartialMatchClient() });
  const result = await runtime.explore({
    task: '인증 함수 확인',
    repo_root: root,
    scope: ['src/**'],
    budget: 'quick',
  });

  // The evidence item at lines 5-6 should be kept as a partial match (read range was 1-4,
  // and 5 is within EVIDENCE_LINE_TOLERANCE=2 of endLine=4)
  assert.ok(result.evidence.length >= 1, 'partial-match evidence should be retained');
  const partialItems = result.evidence.filter(e => e.groundingStatus === 'partial');
  assert.ok(partialItems.length >= 1, 'at least one evidence item should have groundingStatus=partial');
});

test('ExplorerRuntime calls onProgress callback on each turn', async () => {
  class TwoTurnClient {
    constructor() { this.model = 'mock'; this.calls = 0; }
    async createChatCompletion() {
      this.calls += 1;
      if (this.calls === 1) {
        return {
          usage: { prompt_tokens: 50, completion_tokens: 10, total_tokens: 60 },
          message: {
            content: '',
            toolCalls: [{
              id: 'c1',
              function: { name: 'repo_grep', arguments: JSON.stringify({ pattern: 'auth' }) },
            }],
          },
        };
      }
      return {
        usage: { prompt_tokens: 60, completion_tokens: 20, total_tokens: 80 },
        message: {
          content: JSON.stringify({
            answer: '답변', summary: '요약', confidence: 'low',
            evidence: [], candidatePaths: [], followups: [],
          }),
          toolCalls: [],
        },
      };
    }
  }

  const root = await makeRepoFixture();
  const runtime = new ExplorerRuntime({ chatClient: new TwoTurnClient() });
  const progressEvents = [];

  const result = await runtime.explore(
    { task: '인증 함수 찾기', repo_root: root, scope: ['src/**'], budget: 'quick' },
    { onProgress: (evt) => progressEvents.push(evt) },
  );

  assert.ok(progressEvents.length >= 2, 'onProgress must be called at least twice');
  for (const evt of progressEvents) {
    assert.ok(typeof evt.progress === 'number', 'progress must be a number');
    assert.ok(typeof evt.total === 'number', 'total must be a number');
    assert.ok(typeof evt.message === 'string', 'message must be a string');
  }
  assert.ok(result.answer);
});

test('ExplorerRuntime returns sessionId in stats when sessionStore is provided', async () => {
  class SimpleClient {
    constructor() { this.model = 'mock'; }
    async createChatCompletion() {
      return {
        usage: { prompt_tokens: 30, completion_tokens: 10, total_tokens: 40 },
        message: {
          content: JSON.stringify({
            answer: '세션 테스트', summary: '요약', confidence: 'low',
            evidence: [], candidatePaths: ['src/auth.js'], followups: [],
          }),
          toolCalls: [],
        },
      };
    }
  }

  const root = await makeRepoFixture();
  const { SessionStore } = await import('../src/explorer/session.mjs');
  const sessionStore = new SessionStore();

  const runtime = new ExplorerRuntime({ chatClient: new SimpleClient() });
  const result = await runtime.explore(
    { task: '테스트', repo_root: root },
    { sessionStore },
  );

  assert.ok(typeof result.stats.sessionId === 'string', 'stats.sessionId must be a string');
  assert.ok(result.stats.sessionId.startsWith('sess_'), 'sessionId must start with sess_');

  // Session should store candidatePaths from this call
  const session = sessionStore.get(result.stats.sessionId);
  assert.ok(session, 'session must exist in the store');
  assert.ok(session.candidatePaths.includes('src/auth.js'), 'candidatePaths must be accumulated');
});

test('ExplorerRuntime injects previous session context into next call', async () => {
  const capturedPrompts = [];

  class CapturingClient {
    constructor() { this.model = 'mock'; }
    async createChatCompletion({ messages }) {
      capturedPrompts.push(messages[0].content); // system prompt
      return {
        usage: { prompt_tokens: 30, completion_tokens: 10, total_tokens: 40 },
        message: {
          content: JSON.stringify({
            answer: 'ok', summary: 'previous context test', confidence: 'low',
            evidence: [], candidatePaths: [], followups: [],
          }),
          toolCalls: [],
        },
      };
    }
  }

  const root = await makeRepoFixture();
  const { SessionStore } = await import('../src/explorer/session.mjs');
  const sessionStore = new SessionStore();
  const runtime = new ExplorerRuntime({ chatClient: new CapturingClient() });

  // First call — creates session
  const first = await runtime.explore({ task: '첫 번째 탐색', repo_root: root }, { sessionStore });
  const sessionId = first.stats.sessionId;

  // Second call — uses session ID
  await runtime.explore(
    { task: '두 번째 탐색', repo_root: root, session: sessionId },
    { sessionStore },
  );

  // The second system prompt should include the previous summary
  const secondSystemPrompt = capturedPrompts[1];
  assert.ok(
    secondSystemPrompt.includes('previous context test') ||
    secondSystemPrompt.includes('Findings from previous'),
    'Second call must reference previous session summary in system prompt',
  );
});


test('ExplorerRuntime forwards assistant reasoning into the next turn when available', async () => {
  class ReasoningClient {
    constructor() {
      this.model = 'zai-glm-4.7';
      this.calls = 0;
    }

    async createChatCompletion({ messages, reasoningEffort, temperature, topP }) {
      this.calls += 1;

      if (this.calls === 1) {
        assert.equal(reasoningEffort, 'none');
        assert.equal(temperature, 1);
        assert.equal(topP, 0.95);
        return {
          usage: { prompt_tokens: 20, completion_tokens: 10, total_tokens: 30 },
          message: {
            content: '',
            reasoning: 'Search for requireAuth before reading files.',
            toolCalls: [
              {
                id: 'call-r-1',
                function: {
                  name: 'repo_grep',
                  arguments: JSON.stringify({ pattern: 'requireAuth', scope: ['src/**'] }),
                },
              },
            ],
          },
        };
      }

      const assistantMessages = messages.filter(message => message.role === 'assistant');
      assert.ok(
        assistantMessages.some(message => message.reasoning === 'Search for requireAuth before reading files.'),
        'previous assistant reasoning must be sent back on the next turn',
      );

      return {
        usage: { prompt_tokens: 30, completion_tokens: 20, total_tokens: 50 },
        message: {
          content: JSON.stringify({
            answer: 'ok',
            summary: 'reasoning forwarded',
            confidence: 'low',
            evidence: [],
            candidatePaths: [],
            followups: [],
          }),
          reasoning: '',
          toolCalls: [],
        },
      };
    }
  }

  const root = await makeRepoFixture();
  const runtime = new ExplorerRuntime({ chatClient: new ReasoningClient() });
  const result = await runtime.explore({
    task: '인증 함수 위치를 빠르게 찾아라.',
    repo_root: root,
    scope: ['src/**'],
    budget: 'quick',
  });

  assert.equal(result.summary, 'reasoning forwarded');
});
